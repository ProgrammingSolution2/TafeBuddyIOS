//
//  Moodle.swift
//  Tafe Buddy
//
//  Created by Ti Chuot on 9/4/17.
//  Copyright © 2017 Ti Chuot. All rights reserved.
//

import UIKit

class Moodle: UIViewController {
    
    //Set Delegate for UIWebView, the Activity Indicator will start animating when web is loading
    @IBOutlet var webView:UIWebView!
    @IBOutlet weak var loadingIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        let url  = URL(string:"http://learn.tafesa.edu.au")
        let requestObject = URLRequest(url: url!)
        self.webView.loadRequest(requestObject)
        
        //Hide keyboard by tapping anywhere
        self.hideKeyboardWhenTappedAround()

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.navigationController?.hidesBarsOnSwipe = true
    }
    
    func webViewDidStartLoad(_ webView: UIWebView){
        loadingIndicator.startAnimating()
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView){
        loadingIndicator.stopAnimating()
    }
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error){
        
    }
    
    //Hide keyboard by tapping anywhere
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(SignIn.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    
    func dismissKeyboard() {
        view.endEditing(true)
    }

}
